main = do
    mapM_ (\x->putStrLn $ show x) [100,99..1]
    